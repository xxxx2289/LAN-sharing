# LanRemote WebRTC (Android LAN MVP)

This project is an experimental Android screen-sharing/remote-control MVP.

- LAN signaling: WebSocket on host port 8765.
- Media/control: WebRTC PeerConnection and DataChannel.
- Screen capture: MediaProjection; H.264 encoder factory; 1920x1080 maximum and 60fps target.
- Remote actions: tap, long-press, drag/swipe, text entry, clipboard transfer, Back/Home/Recents.
- Pairing: 6-digit PIN.
- GitHub Actions: unpack ZIP, build debug APK, upload APK + source ZIP.

## First-time GitHub setup (important)
GitHub Actions only loads workflow files already committed under `.github/workflows/`.
It cannot execute a workflow that exists only inside an uploaded ZIP. For the first run,
create `.github/workflows/build.yml` using the included `bootstrap-workflow.yml` content,
commit it, then upload this ZIP to the repository root. After bootstrap, uploading a new
`LanRemote-WebRTC.zip` triggers automatic extraction and build.

## Run
1. Install the same APK on both Android devices on the same trusted Wi-Fi.
2. On the host device tap Start host, approve screen capture, then enable LanRemote
   under Android Accessibility settings.
3. Host logs its LAN IP and PIN using Android log tag `LanRemote` (use Logcat).
4. On controller enter `ws://HOST_IP:8765` and PIN, then connect.
5. Use the preview to tap/drag; buttons send Back, keyboard text and clipboard.

## Limitations / security
This is a starter implementation and has not been built or tested on physical devices here.
1080p/60fps is a target, not a guarantee. Device encoder, decoder, Wi-Fi and thermal limits apply.
WebRTC attempts direct LAN ICE host-candidate connectivity; no STUN/TURN or internet relay.
Signaling is plain WebSocket and the PIN is not cryptographic authentication. Do not expose
port 8765 to the internet. Android requires explicit MediaProjection and Accessibility consent.
