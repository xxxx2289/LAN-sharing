package com.example.lanremote
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.webrtc.*
class MainActivity:AppCompatActivity() {
    private val request=77
    private lateinit var status:TextView
    private lateinit var url:EditText
    private lateinit var pin:EditText
    private lateinit var renderer:SurfaceViewRenderer
    private var client:Controller?=null
    override fun onCreate(b:Bundle?){super.onCreate(b); WebRtc.init(this); ui()}
    private fun ui(){
        val root=LinearLayout(this).apply{orientation=1;setPadding(18,18,18,18)}
        status=TextView(this).apply{text="LanRemote：同一局域网使用";textSize=16f}
        url=EditText(this).apply{hint="ws://被控端IP:8765"}
        pin=EditText(this).apply{hint="6 位 PIN"}
        renderer=SurfaceViewRenderer(this).apply{visibility=View.GONE}
        fun btn(s:String,fn:()->Unit)=Button(this).apply{text=s;setOnClickListener{fn()}}
        root.addView(status);root.addView(btn("启动被控端 / 屏幕共享"){val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;startActivityForResult(m.createScreenCaptureIntent(),request)})
        root.addView(btn("打开无障碍设置"){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))})
        root.addView(url);root.addView(pin);root.addView(btn("连接被控端"){connect()})
        root.addView(btn("返回"){client?.send(ControlMessage("back"))})
        root.addView(btn("键盘文字"){val e=EditText(this);android.app.AlertDialog.Builder(this).setTitle("发送文字").setView(e).setPositiveButton("发送"){_,_->client?.send(ControlMessage("text",text=e.text.toString()))}.show()})
        root.addView(btn("同步剪贴板"){val cm=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager;val t=cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty();client?.send(ControlMessage("clipboard",text=t))})
        root.addView(renderer,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
        renderer.setOnTouchListener{_,e->val x=(e.x/renderer.width.coerceAtLeast(1)).coerceIn(0f,1f);val y=(e.y/renderer.height.coerceAtLeast(1)).coerceIn(0f,1f)
            when(e.actionMasked){MotionEvent.ACTION_DOWN->client?.begin(x,y);MotionEvent.ACTION_UP->client?.end(x,y);MotionEvent.ACTION_MOVE->client?.move(x,y)}
            true}
        renderer.setOnLongClickListener{true}
    }
    private fun connect(){val u=url.text.toString().trim();val p=pin.text.toString().trim();if(u.isBlank()||p.length!=6){status.text="请输入 WebSocket 地址和 PIN";return}
        renderer.visibility=View.VISIBLE;renderer.init(WebRtc.egl.eglBaseContext,null);client=Controller(this,u,p,renderer){status.text=it};client?.connect()}
    @Deprecated("legacy activity result")
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==request&&c==Activity.RESULT_OK&&d!=null){
        val i=Intent(this,ProjectionService::class.java).apply{action=ProjectionService.START;putExtra(ProjectionService.CODE,c);putExtra(ProjectionService.DATA,d)}
        if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i) else startService(i)
        status.text="共享服务已启动。请在 Logcat 搜索 LanRemote 获取 IP 和 PIN。"
    }}
    override fun onDestroy(){client?.close();if(::renderer.isInitialized)renderer.release();super.onDestroy()}
}
