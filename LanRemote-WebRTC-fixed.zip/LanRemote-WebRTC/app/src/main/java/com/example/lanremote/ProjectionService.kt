package com.example.lanremote
import android.app.*
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import org.webrtc.*
import java.net.Inet4Address
import java.net.NetworkInterface
class ProjectionService:Service() {
    companion object { const val START="start"; const val CODE="code"; const val DATA="data"; const val CHANNEL="lanremote" }
    private var server:SignalServer?=null
    private var factory:PeerConnectionFactory?=null
    private var source:VideoSource?=null
    private var track:VideoTrack?=null
    private var capturer:ScreenCapturerAndroid?=null
    private var peer:PeerConnection?=null
    private var projection:MediaProjection?=null
    private val gson=com.google.gson.Gson()
    override fun onBind(i:Intent?):IBinder?=null
    override fun onStartCommand(i:Intent?,f:Int,id:Int):Int {
        if(i?.action==START) {
            val nm=getSystemService(NotificationManager::class.java)
            if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(CHANNEL,"Screen sharing",NotificationManager.IMPORTANCE_LOW))
            startForeground(9,NotificationCompat.Builder(this,CHANNEL).setContentTitle("LanRemote 屏幕共享中").setSmallIcon(android.R.drawable.ic_menu_view).build())
            begin(i)
        }; return START_NOT_STICKY
    }
    private fun begin(i:Intent) {
        val data=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(DATA,Intent::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(DATA)
        val code=i.getIntExtra(CODE,Activity.RESULT_CANCELED); if(data==null||code!=Activity.RESULT_OK)return
        projection=(getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code,data)
        factory=WebRtc.factory(); source=factory!!.createVideoSource(true)
        capturer=ScreenCapturerAndroid(data,object:MediaProjection.Callback(){ override fun onStop(){ stopSelf() }})
        val helper=SurfaceTextureHelper.create("capture",WebRtc.egl.eglBaseContext)
        capturer!!.initialize(helper,this,source!!.capturerObserver)
        val dm=DisplayMetrics(); @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val scale=minOf(1f,1920f/dm.widthPixels,1080f/dm.heightPixels)
        val w=((dm.widthPixels*scale).toInt()/2)*2; val h=((dm.heightPixels*scale).toInt()/2)*2
        capturer!!.startCapture(w.coerceAtLeast(2),h.coerceAtLeast(2),60)
        track=factory!!.createVideoTrack("screen",source)
        val pin=(100000..999999).random().toString()
        server=SignalServer(pin){ handle(it) }.also{it.start()}
        android.util.Log.i("LanRemote","HOST ws://${ipv4()}:8765 PIN=$pin")
    }
    private fun handle(raw:String) {
        val m=gson.fromJson(raw,SignalMessage::class.java)
        when(m.type) {
            "offer" -> {
                val pc=createPeer(); peer=pc
                pc.setRemoteDescription(SdpObserverAdapter(),SessionDescription(SessionDescription.Type.OFFER,m.sdp?:return))
                pc.createAnswer(object:SdpObserverAdapter(){ override fun onCreateSuccess(d:SessionDescription){
                    pc.setLocalDescription(SdpObserverAdapter(),d); server?.sendJson(gson.toJson(SignalMessage("answer",sdp=d.description)))
                }},MediaConstraints())
            }
            "ice" -> m.candidate?.let{ peer?.addIceCandidate(IceCandidate(it.sdpMid,it.sdpMLineIndex,it.sdp)) }
        }
    }
    private fun createPeer():PeerConnection {
        return factory!!.createPeerConnection(WebRtc.config(),object:PeerConnection.Observer {
            override fun onIceCandidate(c:IceCandidate){ server?.sendJson(gson.toJson(SignalMessage("ice",candidate=CandidateDto(c.sdpMid,c.sdpMLineIndex,c.sdp)))) }
            override fun onDataChannel(c:DataChannel){ c.registerObserver(object:DataChannel.Observer{
                override fun onBufferedAmountChange(n:Long){}; override fun onStateChange(){}
                override fun onMessage(b:DataChannel.Buffer){ if(b.binary)return; val a=ByteArray(b.data.remaining()); b.data.get(a); RemoteAccessibilityService.active?.runRemote(gson.fromJson(String(a),ControlMessage::class.java)) }
            }) }
            override fun onSignalingChange(s:PeerConnection.SignalingState?){}; override fun onIceConnectionChange(s:PeerConnection.IceConnectionState?){}
            override fun onIceConnectionReceivingChange(b:Boolean){}; override fun onIceGatheringChange(s:PeerConnection.IceGatheringState?){}
            override fun onIceCandidatesRemoved(c:Array<out IceCandidate>?){}; override fun onAddStream(s:MediaStream?){}
            override fun onRemoveStream(s:MediaStream?){}; override fun onRenegotiationNeeded(){}
            override fun onAddTrack(r:RtpReceiver?,s:Array<out MediaStream>?){}; override fun onTrack(t:RtpTransceiver?){}
            override fun onConnectionChange(s:PeerConnection.PeerConnectionState?){}
        }).also{it.addTrack(track!!,listOf("screen-stream"))} ?: error("Peer creation failed")
    }
    private fun ipv4():String = try { NetworkInterface.getNetworkInterfaces().toList().flatMap{it.inetAddresses.toList()}.filterIsInstance<Inet4Address>().first{!it.isLoopbackAddress}.hostAddress?: "0.0.0.0" }catch(_:Exception){"0.0.0.0"}
    override fun onDestroy(){ server?.stop(); capturer?.stopCapture(); capturer?.dispose(); peer?.close(); peer?.dispose(); track?.dispose(); source?.dispose(); factory?.dispose(); projection?.stop(); super.onDestroy() }
}
