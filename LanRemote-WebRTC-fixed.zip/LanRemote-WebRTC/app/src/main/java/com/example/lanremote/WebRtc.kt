package com.example.lanremote
import android.content.Context
import org.webrtc.*
object WebRtc {
    lateinit var egl:EglBase
    private var ready=false
    fun init(c:Context) { if(ready)return
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(c).createInitializationOptions())
        egl=EglBase.create(); ready=true
    }
    fun factory():PeerConnectionFactory = PeerConnectionFactory.builder()
        .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext,true,true))
        .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext)).createPeerConnectionFactory()
    fun config()=PeerConnection.RTCConfiguration(emptyList()).apply {
        sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN
        bundlePolicy=PeerConnection.BundlePolicy.MAXBUNDLE
        rtcpMuxPolicy=PeerConnection.RtcpMuxPolicy.REQUIRE
        iceCandidatePoolSize=4
    }
}
open class SdpObserverAdapter: SdpObserver {
    override fun onCreateSuccess(d:SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(s:String?) { android.util.Log.e("LanRemote","SDP create $s") }
    override fun onSetFailure(s:String?) { android.util.Log.e("LanRemote","SDP set $s") }
}
