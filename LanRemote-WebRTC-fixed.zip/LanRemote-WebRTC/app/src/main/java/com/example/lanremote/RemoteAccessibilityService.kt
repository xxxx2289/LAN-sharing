package com.example.lanremote
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
class RemoteAccessibilityService:AccessibilityService() {
    companion object { @Volatile var active:RemoteAccessibilityService?=null }
    override fun onServiceConnected(){ active=this }
    override fun onAccessibilityEvent(e:AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy(){ if(active===this)active=null; super.onDestroy() }
    fun runRemote(m:ControlMessage) {
        when(m.action) {
            "tap" -> dispatch(m.x,m.y,m.x,m.y,80)
            "long" -> dispatch(m.x,m.y,m.x,m.y,900)
            "swipe" -> dispatch(m.x,m.y,m.x2,m.y2,250)
            "text" -> {
                val args=Bundle().apply { putCharSequence(AccessibilityService.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,m.text.take(3000)) }
                // Android only permits SET_TEXT on an accessible focused editable node.
                rootInActiveWindow?.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT)?.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT,args)
            }
            "clipboard" -> {
                val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("LanRemote",m.text.take(10000)))
            }
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
    }
    private fun dispatch(x:Float,y:Float,x2:Float,y2:Float,duration:Long) {
        val dm=resources.displayMetrics
        val p=Path().apply { moveTo(x*dm.widthPixels,y*dm.heightPixels); lineTo(x2*dm.widthPixels,y2*dm.heightPixels) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,duration)).build(),null,null)
    }
}
