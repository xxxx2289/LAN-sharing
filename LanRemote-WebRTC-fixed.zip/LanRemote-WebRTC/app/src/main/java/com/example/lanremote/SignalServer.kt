package com.example.lanremote
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import java.net.InetSocketAddress
class SignalServer(private val pin:String, private val receive:(String)->Unit):WebSocketServer(InetSocketAddress("0.0.0.0",8765)) {
    @Volatile private var client:WebSocket?=null
    override fun onOpen(c:WebSocket,h:ClientHandshake) { client=c }
    override fun onClose(c:WebSocket,code:Int,reason:String,remote:Boolean) { if(client==c)client=null }
    override fun onMessage(c:WebSocket,msg:String) {
        try {
            val m=com.google.gson.Gson().fromJson(msg,SignalMessage::class.java)
            if(m.type=="auth" && m.pin==pin) c.send("{\"type\":\"auth_ok\"}")
            else if(m.type=="auth") c.close(4001,"PIN rejected")
            else if(c==client) receive(msg)
        } catch(e:Exception) { c.close(4002,"Invalid signaling message") }
    }
    override fun onError(c:WebSocket?,e:Exception) { android.util.Log.e("LanRemote","WS",e) }
    override fun onStart() {}
    fun sendJson(s:String) { client?.send(s) }
}
