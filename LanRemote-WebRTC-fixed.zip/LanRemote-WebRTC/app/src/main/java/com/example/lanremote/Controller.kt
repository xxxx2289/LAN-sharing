package com.example.lanremote
import android.content.Context
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.webrtc.*
import java.net.URI
import java.nio.ByteBuffer
class Controller(ctx:Context,private val url:String,private val pin:String,private val view:SurfaceViewRenderer,private val status:(String)->Unit){
    private val gson=com.google.gson.Gson()
    private val factory=WebRtc.factory()
    private var pc:PeerConnection?=null
    private var dc:DataChannel?=null
    private var ws:WebSocketClient?=null
    fun connect(){ws=object:WebSocketClient(URI(url)){
        override fun onOpen(h:ServerHandshake?){send(gson.toJson(SignalMessage("auth",pin=pin)));status("信令连接成功，等待认证")}
        override fun onMessage(s:String){val m=gson.fromJson(s,SignalMessage::class.java);when(m.type){
            "auth_ok"->offer()
            "answer"->m.sdp?.let{pc?.setRemoteDescription(SdpObserverAdapter(),SessionDescription(SessionDescription.Type.ANSWER,it))}
            "ice"->m.candidate?.let{pc?.addIceCandidate(IceCandidate(it.sdpMid,it.sdpMLineIndex,it.sdp))}
        }}
        override fun onClose(c:Int,r:String?,remote:Boolean){status("信令断开：$r")}
        override fun onError(e:Exception?){status("连接失败：${e?.message}")}
    }.also{it.connect()}}
    private fun offer(){
        pc=factory.createPeerConnection(WebRtc.config(),object:PeerConnection.Observer{
            override fun onIceCandidate(c:IceCandidate){ws?.send(gson.toJson(SignalMessage("ice",candidate=CandidateDto(c.sdpMid,c.sdpMLineIndex,c.sdp))))}
            override fun onTrack(t:RtpTransceiver?){(t?.receiver?.track() as? VideoTrack)?.addSink(view);status("WebRTC 媒体连接已建立")}
            override fun onSignalingChange(s:PeerConnection.SignalingState?){};override fun onIceConnectionChange(s:PeerConnection.IceConnectionState?){status("ICE: $s")}
            override fun onIceConnectionReceivingChange(b:Boolean){};override fun onIceGatheringChange(s:PeerConnection.IceGatheringState?){}
            override fun onIceCandidatesRemoved(c:Array<out IceCandidate>?){};override fun onAddStream(s:MediaStream?){}
            override fun onRemoveStream(s:MediaStream?){};override fun onDataChannel(c:DataChannel?){}
            override fun onRenegotiationNeeded(){};override fun onAddTrack(r:RtpReceiver?,s:Array<out MediaStream>?){}
            override fun onConnectionChange(s:PeerConnection.PeerConnectionState?){}
        })?:run{status("PeerConnection 创建失败");return}
        dc=pc!!.createDataChannel("control",DataChannel.Init())
        pc!!.createOffer(object:SdpObserverAdapter(){override fun onCreateSuccess(d:SessionDescription){pc?.setLocalDescription(SdpObserverAdapter(),d);ws?.send(gson.toJson(SignalMessage("offer",sdp=d.description))) }},MediaConstraints())
    }
    fun begin(x:Float,y:Float){send(ControlMessage("tap",x,y))}
    fun move(x:Float,y:Float){}
    fun end(x:Float,y:Float){send(ControlMessage("tap",x,y))}
    fun send(m:ControlMessage){val c=dc?:return;if(c.state()!=DataChannel.State.OPEN)return;val b=gson.toJson(m).toByteArray();c.send(DataChannel.Buffer(ByteBuffer.wrap(b),false))}
    fun close(){ws?.close();dc?.close();pc?.close();pc?.dispose();factory.dispose()}
}
