package com.example.lanremote
data class ControlMessage(val action:String, val x:Float=0f, val y:Float=0f, val x2:Float=0f, val y2:Float=0f, val text:String="")
data class CandidateDto(val sdpMid:String?, val sdpMLineIndex:Int, val sdp:String)
data class SignalMessage(val type:String, val sdp:String?=null, val candidate:CandidateDto?=null, val pin:String?=null)
